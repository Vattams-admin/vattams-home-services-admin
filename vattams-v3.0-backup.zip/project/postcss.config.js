export default { plugins: { autoprefixer: {} } }
